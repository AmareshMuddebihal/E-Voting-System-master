It is an advanced voting system which works on identification of citizen like Aadhaar. Enrolment/Aadhaar number will be used as your identification along with retina/thumb scan for security purposes. 
The specific objectives of the project include:
	->Reviewing the existing/current voting process or approach.
	->Coming up with an automated  voting system 
	->Implementing an automated/Smart voting system.
	->Validating the system to ensure that only legible voters are allowed to vote.
	->Terminate fake voting.
 Following tools and languages have been used while creating this software:
	->Notepad++(for writing code)
	->CMD(for compiling)
	->JAVA SWING, AWT(for designing GUI)
	->JAVA
	->SQL
